package part2;

class Assemble implements Workshop {
 @Override public void work() 
 { 
     System.out.println(" Assembing Vehicle."); 
 } 

} 