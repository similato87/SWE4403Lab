package part2;

class Produce implements Workshop {
 @Override public void work() 
 { 
     System.out.print("Producing Vehicle"); 
 } 
} 
