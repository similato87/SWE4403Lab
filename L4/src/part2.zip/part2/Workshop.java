package part2;

interface Workshop
{ 
 abstract public void work(); 
} 